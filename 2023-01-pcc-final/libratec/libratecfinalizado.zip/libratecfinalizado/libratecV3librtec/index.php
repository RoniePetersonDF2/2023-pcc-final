<?php
    header('Content-Type: text/html; charset=utf-8');
    header('location: app/views/index.php');